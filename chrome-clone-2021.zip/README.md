[1. 과제 - 핸들러 이용하여 화면동작](https://codesandbox.io/s/day-three-blueprint-forked-ijvgy?file=/src/index.js)

- 슈퍼핸들러 안에 여러 핸들러를 만들어 그 동작에 따라 글내용, 글자색을 바꾸기 정답(https://codesandbox.io/s/day-three-solution-3n53e)

[2. 과제 - if, else를 이용한 event처리](https://codesandbox.io/s/empty-blueprint-forked-gi6zt)

- window.innerWidth를 이용하여 인터넷 창의 사이즈를 변수에 담아 넓이에 따라 if, else문을 사용하여 색깔변화 이때 색깔변화는 classList를 이용해 html에 추가 제거하여 css를 적용시킨다 정답(같은 링크에 주석처리로 넣어놓음)

[3. 과제 - 랜덤 숫자 맞추기](https://codesandbox.io/s/empty-blueprint-forked-05ttg)

- form을 이용하여 값을 랜덤범위의 최대값, 추측값을 보내 결과값을 반환 정답(https://codesandbox.io/s/a07solution-fnylk)

[4. 과제 - D-Day 만들기](https://codesandbox.io/s/a08blueprint-forked-t0vby)

- Date 객체를 생성하는 생성자를 이용하여 지정날짜, 현재날짜를 가져와 서로 뺀뒤 그 차이의 밀리초단위의 시간을 각각 날짜, 시, 분, 초에 맞게 나누어 계산 후 출력 정답(https://codesandbox.io/s/a08solution-s9o2m)

[5. 과제 - 랜덤 그라데이션 색](https://codesandbox.io/s/a09blueprint-forked-qc7tw?file=/src/index.js)

- 주어진 색을 Math.random()함수를 이용하여 중복되지 않게 가져온 후 그 두색을 linear-gradient를 이용하여 중앙의 버튼 클릭시 body태그 style에 적용하여 색을 클릭마다 바꾼다. 정답(https://codesandbox.io/s/a09solution-zz40g)
